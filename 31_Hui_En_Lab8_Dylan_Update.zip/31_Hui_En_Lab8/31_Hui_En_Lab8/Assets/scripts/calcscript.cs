﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class calcscript : MonoBehaviour
{
    public InputField input;
    public float inputamt;
    public float usd = 0.74f;
    public float jpy = 82.78f;
    public float RM = 3.08f;
    public float Eur = 0.63f;
    public float Krw = 881.54f;
    public float Twd = 20.73f;

    public float result;
    public InputField resultbox;

    public Toggle toggle1;
    public Toggle toggle2;
    public Toggle toggle3;
    public Toggle toggle4;
    public Toggle toggle5;
    public Toggle toggle6;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public void convert()
    {
        inputamt = float.Parse(input.text);

        
        if (toggle1.isOn == true)
        {
            exchange1();
        }
        if (toggle2.isOn == true)
        {
            exchange2();
        }
        if (toggle3.isOn == true)
        {
            exchange3();
        }
        if (toggle4.isOn == true)
        {
            exchange4();
        }
        if (toggle5.isOn == true)
        {
            exchange5();
        }
        if (toggle6.isOn == true)
        {
            exchange6();
        }

    }
    public void exchange1()
    {
        result = inputamt * usd;
        resultbox.text = result.ToString() + "USD";
    }
    public void exchange2()
    {
        result = inputamt * jpy;
        resultbox.text = result.ToString() + "¥";
    }
    public void exchange3()
    {
        result = inputamt * RM;
        resultbox.text = result.ToString() + " Ringgit";
    }
    public void exchange4()
    {
        result = inputamt * Eur;
        resultbox.text = result.ToString() + " Euro";
    }
    public void exchange5()
    {
        result = inputamt * Krw;
        resultbox.text = result.ToString() + " Korea Won";
    }
    public void exchange6()
    {
        result = inputamt * Twd;
        resultbox.text = result.ToString() + " Taiwan Dollar";
    }
    public void clear()
    {
        inputamt = 0;
        input.text = "0";
        result = 0;
        resultbox.text="0";
    }
    
}
