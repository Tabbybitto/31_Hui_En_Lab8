﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class calcscript : MonoBehaviour
{
    public InputField input;
    public float inputamt;
    public float usd = 0.74f;
    public float jpy = 82.78f;

    public float result;
    public InputField resultbox;

    public Toggle toggle1;
    public Toggle toggle2;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    
    public void convert()
    {
        inputamt = float.Parse(input.text);

        
        if (toggle1.isOn == true)
        {
            exchange1();
        }
        else if (toggle2.isOn == true)
        {
            exchange2();
        }
                
        
    }
    public void exchange1()
    {
        result = inputamt * usd;
        resultbox.text = result.ToString() + "USD";
    }
    public void exchange2()
    {
        result = inputamt * jpy;
        resultbox.text = result.ToString() + "¥";
    }
    public void clear()
    {
        inputamt = 0;
        input.text = "0";
        result = 0;
        resultbox.text="0";
    }
    
}
